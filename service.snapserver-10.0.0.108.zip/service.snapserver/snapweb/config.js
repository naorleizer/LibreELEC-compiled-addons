"use strict";
let config = {
    baseUrl: (window.location.protocol === 'https:' ? 'wss://' : 'ws://') + window.location.host
};
//# sourceMappingURL=config.js.map