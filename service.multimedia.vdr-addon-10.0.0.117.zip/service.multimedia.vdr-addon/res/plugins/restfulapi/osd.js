//bootstrap will be called on onload event
function bootstrap()
{
  //alert("javascript bootstrap called!");
}
